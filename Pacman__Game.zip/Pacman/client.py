import socket
import os
import threading
import pickle
import pygame
from game_objects import SCREEN_WIDTH, SCREEN_HEIGHT, TILE_SIZE, MAZE_BOARD

HOST = '127.0.0.1'
PORT = 50007

class GameClient:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((HOST, PORT))
        self.state = None
        self.running = True
        self.player_idx = None
        self.lock = threading.Lock()

    def receive_thread(self):
        while self.running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    break
                state = pickle.loads(data)
                with self.lock:
                    self.state = state
            except:
                break
        self.running = False

    def send_input(self, direction):
        try:
            self.sock.sendall(pickle.dumps(direction))
        except:
            self.running = False

    def run(self):
        pygame.init()
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Pac-Dual Networked Client")
        clock = pygame.time.Clock()

        def load_img(filename):
            try:
                return pygame.transform.scale(pygame.image.load(filename).convert_alpha(), (TILE_SIZE, TILE_SIZE))
            except Exception as e:
                print(f"Warning: Could not load {filename}: {e}")
                return None
        player_images = [
            load_img("left_baz.png"),
            load_img("right_baz.png")
        ]
        ghost_image = load_img("green_ghost.png")
        player_ghost_image = load_img("red_ghost.png")
        threading.Thread(target=self.receive_thread, daemon=True).start()
        
        while self.running:
            direction = None
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w or event.key == pygame.K_UP:
                        direction = 'up'
                    elif event.key == pygame.K_s or event.key == pygame.K_DOWN:
                        direction = 'down'
                    elif event.key == pygame.K_a or event.key == pygame.K_LEFT:
                        direction = 'left'
                    elif event.key == pygame.K_d or event.key == pygame.K_RIGHT:
                        direction = 'right'
            if direction:
                self.send_input(direction)
            screen.fill((0, 0, 0))

            mid_x = (screen.get_width() // 2)
            pygame.draw.line(screen, (255, 255, 255), (mid_x, 0), (mid_x, screen.get_height()), 3)

            for y, row in enumerate(MAZE_BOARD):
                for x, char in enumerate(row):
                    if char == '#':
                        pygame.draw.rect(screen, (50, 50, 255), (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                    elif char == '=':
                        pygame.draw.rect(screen, (255, 255, 255), (x * TILE_SIZE, y * TILE_SIZE + 10, TILE_SIZE, TILE_SIZE - 20))
                    elif char == '+':
                        pygame.draw.rect(screen, (255, 255, 255), (x * TILE_SIZE + 10, y * TILE_SIZE, TILE_SIZE - 20, TILE_SIZE))

            with self.lock:
                state = self.state
            if state:
                for (x, y) in state['dots']:
                    pygame.draw.rect(screen, (255, 255, 0), (x * TILE_SIZE + TILE_SIZE//2 - 3, y * TILE_SIZE + TILE_SIZE//2 - 3, 6, 6))

                for (x, y) in state.get('power_pellets', []):
                    pygame.draw.circle(screen, (255, 255, 0), (x * TILE_SIZE + TILE_SIZE//2, y * TILE_SIZE + TILE_SIZE//2), 12)

                direction_to_angle = {'right': 0, 'down': 270, 'left': 180, 'up': 90}
                for idx, (x, y, score, last_direction, is_ghost) in enumerate(state['players']):
                    if is_ghost:
                        if player_ghost_image:
                            screen.blit(player_ghost_image, (x * TILE_SIZE, y * TILE_SIZE))
                        else:
                            pygame.draw.rect(screen, (200, 0, 0), (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                    elif player_images[idx]:
                        angle = direction_to_angle.get(last_direction, 0)
                        rotated_img = pygame.transform.rotate(player_images[idx], angle)
                        screen.blit(rotated_img, (x * TILE_SIZE, y * TILE_SIZE))
                    else:
                        color = (0, 255, 255) if idx == 0 else (255, 100, 100)
                        pygame.draw.rect(screen, color, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))

                for i, (x, y) in enumerate(state['ghosts']):
                    if ghost_image:
                        screen.blit(ghost_image, (x * TILE_SIZE, y * TILE_SIZE))
                    else:
                        pygame.draw.rect(screen, (0, 255, 0), (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))

                    if state.get('ghosts_frozen', [False]*len(state['ghosts']))[i]:
                        pygame.draw.circle(screen, (0, 150, 255), (x * TILE_SIZE + TILE_SIZE//2, y * TILE_SIZE + TILE_SIZE//2), TILE_SIZE//2, 4)

                if state.get('game_over'):
                    font = pygame.font.SysFont(None, 72)
                    winner = state.get('winner')
                    if winner is not None:
                        text = font.render(f"Player {winner+1} Wins!", True, (255, 255, 0))
                    else:
                        text = font.render("Game Over!", True, (255, 255, 0))
                    rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
                    screen.blit(text, rect)
                    pygame.display.flip()
                    pygame.time.wait(4000)
                    self.running = False
                    break
            pygame.display.flip()
            clock.tick(30)
        pygame.quit()
        self.sock.close()

if __name__ == '__main__':
    GameClient().run() 