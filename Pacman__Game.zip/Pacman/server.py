import socket
import threading
import pickle
from game_objects import Player, Maze, Ghost, MAZE_BOARD
import time

HOST = '0.0.0.0'
PORT = 50007

class GameServer:
    def __init__(self):
        self.clients = []
        self.players = [
            Player("left", 3, 8, (0, 255, 255), None, side="left"),
            Player("right", 19, 8, (255, 100, 100), None, side="right")
        ]
        self.maze = Maze(MAZE_BOARD)
        self.ghosts = [Ghost(5, 3), Ghost(1, 9), Ghost(21, 3), Ghost(13, 3)]
        self.lock = threading.Lock()
        self.inputs = [None, None]
        self.running = True

    def handle_client(self, conn, player_idx):
        while self.running:
            try:
                data = conn.recv(4096)
                if not data:
                    break
                direction = pickle.loads(data)
                with self.lock:
                    self.inputs[player_idx] = direction
            except:
                break
            
        conn.close()
        with self.lock:
            self.clients[player_idx] = None
        print(f"Player {player_idx+1} disconnected")

    def game_loop(self):
        winner = None
        game_over = False
        end_time = None
        while self.running:
            with self.lock:
                if not game_over:
                    for idx, player in enumerate(self.players):
                        direction = self.inputs[idx]
                        if direction:
                            player.move(direction, self.maze.layout)
                            self.inputs[idx] = None
                            self.maze.collect_dot(player)
                            if self.maze.collect_power_pellet(player):
                                print(f"Player {idx+1} collected a power pellet!")
                                player_half = 'left' if player.side == 'left' else 'right'

                                for ghost in self.ghosts:
                                    if player_half == 'left' and ghost.x < (len(self.maze.layout[0]) + 1) // 2:
                                        ghost.freeze(5)
                                    elif player_half == 'right' and ghost.x >= (len(self.maze.layout[0]) + 1) // 2:
                                        ghost.freeze(5)

                    for idx, player in enumerate(self.players):
                        if player.side == 'left':
                            half_dots = [(x, y) for (x, y) in self.maze.dots if x < (len(self.maze.layout[0]) + 1) // 2]
                        else:
                            half_dots = [(x, y) for (x, y) in self.maze.dots if x >= (len(self.maze.layout[0]) + 1) // 2]
                        if not half_dots:
                            winner = idx
                            game_over = True
                            end_time = time.time() + 5
                            print(f"Player {idx+1} wins by collecting all dots!")

                    p1, p2 = self.players
                    if p1.is_ghost() and not p2.is_ghost() and p1.x == p2.x and p1.y == p2.y:
                        winner = 0
                        game_over = True
                        end_time = time.time() + 5
                        print("Player 1 wins by capturing Player 2!")
                    elif p2.is_ghost() and not p1.is_ghost() and p1.x == p2.x and p1.y == p2.y:
                        winner = 1
                        game_over = True
                        end_time = time.time() + 5
                        print("Player 2 wins by capturing Player 1!")

                targets = [p for p in self.players if not p.is_ghost()]
                for ghost in self.ghosts:
                    if targets:
                        closest = min(targets, key=lambda p: abs(p.x - ghost.x) + abs(p.y - ghost.y))
                        ghost.move(self.maze.layout, closest.x, closest.y, False)

                if not game_over:
                    for idx, player in enumerate(self.players):
                        if not player.is_ghost():
                            for i, ghost in enumerate(self.ghosts):
                                if player.x == ghost.x and player.y == ghost.y:
                                    if ghost.frozen_until > time.time():
                                        ghost.reset_to_start()
                                        print(f"Player {idx+1} hit frozen ghost {i+1} - ghost returned to start!")
                                    else:
                                        winner = 1 - idx
                                        game_over = True
                                        end_time = time.time() + 5
                                        print(f"Player {winner+1} wins! (Ghost caught Player {idx+1})")

            state = {
                'players': [(p.x, p.y, p.score, p.last_direction, p.is_ghost()) for p in self.players],
                'ghosts': [(g.x, g.y) for g in self.ghosts],
                'dots': list(self.maze.dots),
                'power_pellets': list(self.maze.power_pellets),
                'ghosts_frozen': [g.frozen_until > time.time() for g in self.ghosts],
                'game_over': game_over,
                'winner': winner,
            }
            data = pickle.dumps(state)
            for c in self.clients:
                if c:
                    try:
                        c.sendall(data)
                    except:
                        pass
            if game_over and end_time and time.time() > end_time:
                self.running = False
            time.sleep(0.1)

    def start(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen()
        print(f"Server listening on {HOST}:{PORT}")

        for i in range(2):
            conn, addr = s.accept()
            print(f"Player {i+1} connected from {addr}")
            self.clients.append(conn)
            threading.Thread(target=self.handle_client, args=(conn, i), daemon=True).start()
        self.game_loop()

if __name__ == '__main__':
    GameServer().start() 