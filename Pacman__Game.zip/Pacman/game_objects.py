import random
import time

SCREEN_WIDTH = 832
SCREEN_HEIGHT = 416
TILE_SIZE = 32
ROWS = SCREEN_HEIGHT // TILE_SIZE
COLS = SCREEN_WIDTH // TILE_SIZE
MAZE_BOARD = [
    "##########################",
    "#........*...............#",
    "#..##=##...####....##=##.#",
    "#..#@@@#....#@+....#@@@#.#",
    "#..#@@@#....#@+....#####.#",
    "#..#####.#..#####........#",
    "#........#...*...#..##...#",
    "#.######.#.#####.######..#",
    "#=#.....................##",
    "#@########################"
]

class Player:
    def __init__(self, name, x, y, base_color, controls, side):
        self.name = name
        self.x = x
        self.y = y
        self.base_color = base_color
        self.controls = controls
        self.side = side
        self.speed = 1
        self.score = 0
        self.is_ghost_flag = False
        self.last_direction = 'right'

    def is_ghost(self):
        if self.side == "left" and self.x >= (COLS+1)//2:
            return True
        if self.side == "right" and self.x < (COLS+1)//2:
            return True
        return False

    def move(self, direction, maze):
        dx = 0
        dy = 0
        if direction == 'up': dy = -1
        if direction == 'down': dy = 1
        if direction == 'left': dx = -1
        if direction == 'right': dx = 1
        if direction in ['up', 'down', 'left', 'right']:
            self.last_direction = direction
        new_x = self.x + dx
        new_y = self.y + dy
        if 0 <= new_y < len(maze) and 0 <= new_x < len(maze[0]):
            if maze[new_y][new_x] != "#":
                self.x = new_x
                self.y = new_y

class Maze:
    def __init__(self, layout):
        self.layout = layout
        self.dots = set()
        self.power_pellets = set()
        for y, row in enumerate(layout):
            for x, char in enumerate(row):
                if char == ".":
                    self.dots.add((x, y))
                elif char == "*":
                    self.power_pellets.add((x, y))

    def collect_dot(self, player):
        if player.is_ghost():
            return
        pos = (player.x, player.y)
        if pos in self.dots:
            self.dots.remove(pos)
            player.score += 1

    def collect_power_pellet(self, player):
        if player.is_ghost():
            return False
        pos = (player.x, player.y)
        if pos in self.power_pellets:
            self.power_pellets.remove(pos)
            return True
        return False

class Ghost:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.initial_x = x 
        self.initial_y = y
        self.direction = random.choice(["up", "down", "left", "right"])
        self.speed = 1
        self.move_cooldown = 4
        self.move_counter = 0
        self.frozen_until = 0

    def freeze(self, duration):
        self.frozen_until = time.time() + duration

    def reset_to_start(self):
        self.x = self.initial_x
        self.y = self.initial_y

    def move(self, maze, target_x, target_y, target_is_ghost):
        if self.frozen_until > time.time():
            return
        self.move_counter += 1
        if self.move_counter < self.move_cooldown:
            return
        self.move_counter = 0
        if target_is_ghost:
            return
        directions = {
            "up": (0, -1),
            "down": (0, 1),
            "left": (-1, 0),
            "right": (1, 0)
        }
        best_dir = None
        min_distance = float('inf')
        for dir, (dx, dy) in directions.items():
            new_x = self.x + dx
            new_y = self.y + dy
            if 0 <= new_x < len(maze[0]) and 0 <= new_y < len(maze):
                if maze[new_y][new_x] not in ['#', '@']:
                    dist = abs(new_x - target_x) + abs(new_y - target_y)
                    if dist < min_distance:
                        min_distance = dist
                        best_dir = (dx, dy)
        if best_dir:
            self.x += best_dir[0]
            self.y += best_dir[1] 